#!/bin/bash

log_folder=/opt/cloudwiz-agent/altenv/var/log

if [[ ! -d $log_folder ]]; then
    mkdir "$log_folder"
fi

/opt/cloudwiz-agent/uagent/daemon.py --logfile "$log_folder/uagent.log" "$@"
